var data = fetch("veri.json")
.then(response=>response.json())
.then(veri=>{
    console.log(veri);
    console.log(veri.kullanicilar[2].Ad);
    console.log(veri.yetki);
   
    })



