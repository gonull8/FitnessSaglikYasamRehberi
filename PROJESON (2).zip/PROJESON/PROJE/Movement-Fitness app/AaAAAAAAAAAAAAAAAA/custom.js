var data = fetch("veri.json")
.then(response=>response.json())
.then(veri=>{
    console.log(veri);
    console.log(veri.kullanicilar);
    console.log(veri.yetki);
    console.log(veri.YemekTarifleri);
    console.log(veri.Egzersizler);

    })